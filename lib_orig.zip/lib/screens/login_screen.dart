import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:newsdx/app_constants/string_constant.dart';
import 'package:newsdx/router/app_state.dart';
import 'package:newsdx/router/ui_pages.dart';
import 'package:newsdx/screens/otp_screen.dart';
import 'package:newsdx/widgets/app_bar.dart';
import 'package:provider/provider.dart';
import 'package:sign_button/constants.dart';
import 'package:sign_button/create_button.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isLoggedIn = false;
  late GoogleSignInAccount _userObj;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context, listen: false);
    return Scaffold(
        appBar: AppBarWidget(MyConstant.noTitle),
        resizeToAvoidBottomInset: false,
        body: SingleChildScrollView(
          child: Column(
            children: [
              Row(
                children: [
                  const Padding(
                    padding: EdgeInsets.only(
                      left: 16,
                      top: 10,
                    ),
                    child: Icon(Icons.home),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 5,
                      top: 10,
                    ),
                    child: Column(
                      children: const [
                        Text(
                          MyConstant.appName,
                          style: TextStyle(
                            color: Colors.black,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          MyConstant.appType,
                          style: TextStyle(
                              color: Colors.grey,
                              fontSize: 12,
                              fontWeight: FontWeight.w400),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: EdgeInsets.only(
                      left: 16.0, top: 20.0, right: 0.0, bottom: 10.0),
                  child: Text(
                    MyConstant.loginScreenTitle,
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 25,
                        fontWeight: FontWeight.w800),
                  ),
                ),
              ),
              const Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: EdgeInsets.only(
                      left: 16.0, top: 0.0, right: 0.0, bottom: 10.0),
                  child: Text(
                    MyConstant.loginScreenSubTitle,
                    style: TextStyle(
                        color: Colors.black87,
                        fontSize: 20,
                        fontWeight: FontWeight.w500),
                  ),
                ),
              ),
              const Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: EdgeInsets.only(
                      left: 16.0, top: 20.0, right: 0.0, bottom: 10.0),
                  child: Text(
                    MyConstant.emailErrorMsg,
                    style: TextStyle(
                        color: Colors.black54,
                        fontSize: 16,
                        fontWeight: FontWeight.w300),
                  ),
                ),
              ),
              const Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: EdgeInsets.only(
                      left: 16.0, top: 0.0, right: 16.0, bottom: 10.0),
                  child: TextField(
                    maxLines: 1,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text(MyConstant.emailHint),
                      hintText: MyConstant.emailHint,
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topLeft,
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, top: 20.0, right: 16.0, bottom: 10.0),
                  child: TextButton(
                    onPressed: () {},
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          primary: Colors.blue,
                          minimumSize: const Size.fromHeight(50),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30.0))),
                      child: const Text(MyConstant.signInButtonTitle),
                      onPressed: () {
                        //Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (BuildContext context) => const OTPScreen()));
                        //appState.login();
                        appState.currentAction = PageAction(
                            state: PageState.addWidget,
                            widget: OTPScreen(),
                            page: OtpPageConfig);
                      },
                    ),
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, top: 0.0, right: 0.0, bottom: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    mainAxisSize: MainAxisSize.min,
                    children: const [
                      Text("---------------"),
                      Text("or"),
                      Text("---------------"),
                    ],
                  ),
                ),
              ),
              Align(
                alignment: Alignment.topCenter,
                child: Padding(
                  padding: const EdgeInsets.only(
                      left: 16.0, top: 0.0, right: 0.0, bottom: 0.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SignInButton.mini(
                          buttonType: ButtonType.google, onPressed: () {}),
                      SignInButton.mini(
                          buttonType: ButtonType.facebook, onPressed: () {}),
                      SignInButton.mini(
                          buttonType: ButtonType.apple, onPressed: () {}),
                    ],
                  ),
                ),
              ),
              const SizedBox(
                height: 70,
              ),
              Positioned(
                bottom: 0,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: const [
                    Text(
                      MyConstant.signInScreenPrivacyPolicy,
                      style: TextStyle(color: Colors.grey, fontSize: 12),
                    ),
                    Text(
                      MyConstant.tcTitle,
                      style: TextStyle(color: Colors.blue, fontSize: 14),
                    ),
                    Text("text with image"),
                  ],
                ),
              ),
            ],
          ),
        ));
  }

  void signInWithGoogle() {
    _googleSignIn.signIn().then((userData) {
      setState(() {
        _isLoggedIn = true;
        _userObj = userData!;
      });
    }).catchError((e) {
      print(e);
    });
  }
}
