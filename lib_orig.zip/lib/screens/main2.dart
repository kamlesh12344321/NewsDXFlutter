

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:newsdx/router/app_state.dart';
import 'package:newsdx/router/back_dispatcher.dart';
import 'package:newsdx/router/route_parser.dart';
import 'package:newsdx/router/router_delegate.dart';
import 'package:newsdx/router/ui_pages.dart';
import 'package:provider/provider.dart';
import 'package:uni_links/uni_links.dart';
import 'dart:developer' as developer;

void main() {
runApp(MyApp2());
}

class MyApp2 extends StatefulWidget {
  const MyApp2({Key? key}) : super(key: key);

  @override
  State<MyApp2> createState() => _MyApp2State();
}

class _MyApp2State extends State<MyApp2> {

  final appState = AppState();
  late NewsDxRouterDelegate delegate;
  late NewsDxBackButtonDispatcher backButtonDispatcher;
  late NewsDxRouteParser parser;
  late StreamSubscription _linkSubscription;

  _MyApp2State() {
    delegate = NewsDxRouterDelegate(appState);
    backButtonDispatcher = NewsDxBackButtonDispatcher(delegate);
    parser = NewsDxRouteParser();
  }

  @override
  initState() {
  super.initState();
  initPlatformState();
  }

  @override
  Widget build(BuildContext context) {
    developer.log(Log_Tag , name: "MyApp2State :: build()");
    return ChangeNotifierProvider(
        create: (_) => appState,
        child: MaterialApp.router(
          routeInformationParser: parser,
          routerDelegate: delegate,
          backButtonDispatcher: backButtonDispatcher,
          title: "Navigator App",
          theme: ThemeData(
            primarySwatch: Colors.blue,
            visualDensity: VisualDensity.adaptivePlatformDensity,
          ),
        ),
    );
  }


  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> initPlatformState() async {
    // Attach a listener to the Uri links stream
    _linkSubscription = getUriLinksStream().listen((Uri ?uri) {
      if (!mounted) return;
      setState(() {
        delegate.parseRoute(uri!);
      });
    }, onError: (Object err) {
      print('Got error $err');
    });
  }

  @override
  void dispose() {
    if (_linkSubscription != null) _linkSubscription.cancel();
    super.dispose();
  }

}


