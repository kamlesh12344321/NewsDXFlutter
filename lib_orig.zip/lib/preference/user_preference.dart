import 'package:shared_preferences/shared_preferences.dart';

class LocalPreferenceService {
  static LocalPreferenceService? _instance;
  static SharedPreferences? _preferences;

  static Future<LocalPreferenceService?> getInstance() async {
    _instance ??= LocalPreferenceService();
    _preferences ??= await SharedPreferences.getInstance();
    return _instance;
  }
}