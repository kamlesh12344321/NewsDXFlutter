import 'package:flutter/material.dart';
import 'package:newsdx/router/app_state.dart';
import 'package:newsdx/router/ui_pages.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:developer' as developer;

const String LoggedInKey = 'LoggedIn';

enum PageState { none, addPage, addAll, replace, replaceAll, pop, addWidget }

class PageAction {
  PageState? state;
  PageConfiguration? page;
  List<PageConfiguration>? pages;
  Widget? widget;

  PageAction({this.state, this.page, this.pages, this.widget});
}

class AppState extends ChangeNotifier {
  bool _loggedIn = false;

  bool get loggedIn => _loggedIn;

  bool _splashFinished = false;

  bool get splashFinished => _splashFinished;

  PageAction _currentAction = PageAction();

  PageAction get currentAction => _currentAction;

  set currentAction(PageAction action) {
    _currentAction = action;
    notifyListeners();
  }

  AppState() {
    getLoggedInState();
  }

  resetCurrentAction() {
    _currentAction = PageAction();
  }

  setSplashFinished() {
    developer.log(Log_Tag , name: "#################################");
    developer.log(Log_Tag , name: "AppState :: setSplashFinished()");
    _splashFinished = true;
    if(_loggedIn) {
      _currentAction = PageAction(state: PageState.replaceAll, page: HomePageConfig);
    } else {
      _currentAction = PageAction(state: PageState.replaceAll, page:LoginPageConfig);
    }
    notifyListeners();
  }

  void login() {
    //_loggedIn = true;
    //saveLoginState(loggedIn);
    _currentAction = PageAction(state: PageState.addPage, page: OtpPageConfig);
    notifyListeners();
  }

  getLoggedInState() async {
    var pref = await SharedPreferences.getInstance();
    _loggedIn = pref.getBool(LoggedInKey)!;

    if (_loggedIn == null) {
      _loggedIn = false;
    }
  }
}
